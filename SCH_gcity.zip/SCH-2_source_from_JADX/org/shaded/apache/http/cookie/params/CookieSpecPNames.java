package org.shaded.apache.http.cookie.params;

public interface CookieSpecPNames {
    public static final String DATE_PATTERNS = "http.protocol.cookie-datepatterns";
    public static final String SINGLE_COOKIE_HEADER = "http.protocol.single-cookie-header";
}
