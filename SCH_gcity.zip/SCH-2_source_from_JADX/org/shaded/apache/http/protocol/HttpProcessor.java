package org.shaded.apache.http.protocol;

import org.shaded.apache.http.HttpRequestInterceptor;
import org.shaded.apache.http.HttpResponseInterceptor;

public interface HttpProcessor extends HttpRequestInterceptor, HttpResponseInterceptor {
}
