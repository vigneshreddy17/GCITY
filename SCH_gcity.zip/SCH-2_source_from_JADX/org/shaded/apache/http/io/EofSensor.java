package org.shaded.apache.http.io;

public interface EofSensor {
    boolean isEof();
}
