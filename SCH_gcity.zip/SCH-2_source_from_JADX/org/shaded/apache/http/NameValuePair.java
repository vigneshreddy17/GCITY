package org.shaded.apache.http;

public interface NameValuePair {
    String getName();

    String getValue();
}
