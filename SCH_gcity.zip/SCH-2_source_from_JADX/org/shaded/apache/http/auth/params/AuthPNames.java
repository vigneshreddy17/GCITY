package org.shaded.apache.http.auth.params;

public interface AuthPNames {
    public static final String CREDENTIAL_CHARSET = "http.auth.credential-charset";
}
