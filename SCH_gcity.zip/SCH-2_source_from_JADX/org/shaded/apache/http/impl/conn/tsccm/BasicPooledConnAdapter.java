package org.shaded.apache.http.impl.conn.tsccm;

import org.shaded.apache.http.conn.ClientConnectionManager;
import org.shaded.apache.http.impl.conn.AbstractPoolEntry;
import org.shaded.apache.http.impl.conn.AbstractPooledConnAdapter;

public class BasicPooledConnAdapter extends AbstractPooledConnAdapter {
    protected BasicPooledConnAdapter(ThreadSafeClientConnManager tsccm, AbstractPoolEntry entry) {
        super(tsccm, entry);
        markReusable();
    }

    protected ClientConnectionManager getManager() {
        return super.getManager();
    }

    protected AbstractPoolEntry getPoolEntry() {
        return this.poolEntry;
    }

    protected void detach() {
        super.detach();
    }
}
