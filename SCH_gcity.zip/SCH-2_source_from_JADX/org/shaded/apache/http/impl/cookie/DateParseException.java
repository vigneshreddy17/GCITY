package org.shaded.apache.http.impl.cookie;

import org.shaded.apache.http.annotation.Immutable;

@Immutable
public class DateParseException extends Exception {
    private static final long serialVersionUID = 4417696455000643370L;

    public DateParseException(String message) {
        super(message);
    }
}
